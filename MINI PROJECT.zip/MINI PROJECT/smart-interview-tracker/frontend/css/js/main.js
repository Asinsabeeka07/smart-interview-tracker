// Page Transition Handler
document.addEventListener('DOMContentLoaded', () => {
    // Highlight active nav
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-item').forEach(item => {
        if (item.getAttribute('href') === currentPage) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // Smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';
});

function showToast(message) {
    const toast = document.getElementById('toast');
    if (toast) {
        document.getElementById('toastMessage').textContent = message;
        toast.classList.add('show');
        
        // Play notification sound (optional)
        try {
            const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUBLYnX9tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJIfT89OJNwgjYLXq5sBQEAxPp+HyzWUeBjiOzvM=');
            audio.volume = 0.3;
            audio.play().catch(e => {});
        } catch(e) {}
        
        setTimeout(() => toast.classList.remove('show'), 3000);
    }
}

// Prevent form resubmission on refresh
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
}
