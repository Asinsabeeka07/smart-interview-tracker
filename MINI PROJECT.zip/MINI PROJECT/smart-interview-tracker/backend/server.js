const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

// CORS setup - allow all
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'DELETE'],
    credentials: true
}));

app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date() });
});

// In-memory storage
let interviews = [];
let chatHistory = [];

// ============ CHAT API ============
app.post('/api/chat', (req, res) => {
    try {
        const { message } = req.body;
        
        if (!message) {
            return res.json({ 
                reply: "Hello! Type something to chat.",
                error: false 
            });
        }

        const lower = message.toLowerCase();
        let reply = '';

        // Smart responses
        const responses = {
            'hi': '👋 Vanakkam! Ready for your interviews?',
            'hello': 'Hello! Need help with interview prep?',
            'help': 'I can help with:\n• Interview scheduling\n• Resume tips\n• Success prediction\n• WhatsApp reminders',
            'interview': '📅 Check your Dashboard for upcoming interviews!',
            'prepare': '📚 Focus areas:\n1. System Design\n2. Coding\n3. Company research',
            'nervous': 'Take deep breaths! You are qualified. 💪\n• STAR method\n• Practice answers\n• Sleep well',
            'bye': 'Good luck with your interviews! 🎯',
            'thanks': 'You are welcome! All the best! 🌟'
          'nandri':'paravalla nalla pannu paathukkalam!!!'
        };

        // Check for keywords
        for (let key in responses) {
            if (lower.includes(key)) {
                reply = responses[key];
                break;
            }
        }

        // Default response
        if (!reply) {
            reply = `Interesting! Try asking about:\n• "When is my interview?"\n• "Prepare tips"\n• "Success chance"`;
        }

        res.json({ reply, error: false });

    } catch (err) {
        console.log('Chat error:', err);
        res.json({ 
            reply: "I'm here! What would you like to know?", 
            error: false 
        });
    }
});

// ============ INTERVIEWS ============
app.get('/api/interviews', (req, res) => {
    res.json(interviews);
});

app.post('/api/interviews', (req, res) => {
    const interview = {
        id: Date.now().toString(),
        ...req.body,
        createdAt: new Date()
    };
    interviews.push(interview);
    res.json({ success: true, data: interview });
});

app.delete('/api/interviews/:id', (req, res) => {
    interviews = interviews.filter(i => i.id !== req.params.id);
    res.json({ success: true });
});

// ============ ANALYZE ============
app.post('/api/analyze-resume', (req, res) => {
    const { skills, experience, jobDescription } = req.body;
    let score = 50;
    
    if (skills) {
        const skillCount = skills.split(',').length;
        score += skillCount * 5;
    }
    if (experience) {
        score += parseInt(experience) * 3;
    }
    score = Math.min(score, 100);
    
    res.json({ 
        score, 
        suggestions: ['Add more keywords', 'Include quantifiable achievements'] 
    });
});

// ============ PREDICT ============
app.post('/api/predict', (req, res) => {
    const { preparationHours, resumeScore } = req.body;
    const prob = Math.min(50 + (preparationHours || 0) + (resumeScore || 0)/5, 95);
    
    res.json({
        probability: Math.round(prob),
        recommendation: prob > 70 ? 'Great chance!' : 'Practice more coding'
    });
});

// ============ WHATSAPP ============
app.post('/api/whatsapp', (req, res) => {
    const { phone, message } = req.body;
    const link = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    res.json({ success: true, link });
});

// Serve HTML files
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`✅ Server running: http://localhost:${PORT}`);
    console.log(`✅ Chat API ready`);
});
